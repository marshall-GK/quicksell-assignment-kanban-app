export const LOCALSTORAGE_CACHE_KEY = 'quickSellTicketState';

export const API_BASE_URL = 'https://api.quicksell.co/v1/';
export const TICKET_ASSIGMENT = 'internal/frontend-assignment';