import axios from 'axios';

const apiProvider = axios.create({});

export default apiProvider;