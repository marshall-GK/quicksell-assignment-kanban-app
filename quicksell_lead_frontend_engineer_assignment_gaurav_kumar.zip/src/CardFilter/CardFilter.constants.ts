export const filtersList = [
  {
    key: 'grouping', options: ['status', 'user', 'priority'], default: 'user'
  },
  {
    key: 'ordering', options: ['priority', 'title'], default: 'priority'
  }
]