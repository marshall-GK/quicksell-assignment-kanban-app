import './App.css';
import Ticket from './Ticket/Ticket';

function App() {
  return (
    <div className="App">
      <Ticket />
    </div>
  );
}

export default App;
